import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DB {
    // connects to database Notes
    private static final String URL = "jdbc:mysql://localhost:3306/Notes?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root";    // change if your MySQL user is different
    private static final String PASS = "";        // put your MySQL password here (or leave blank for XAMPP default)

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // ensure driver loaded
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    // init ensures tables exist (safe to call at startup)
    public static void init() {
        String sqlUsers = "CREATE TABLE IF NOT EXISTS users ("
                + "id INT AUTO_INCREMENT PRIMARY KEY,"
                + "username VARCHAR(50) UNIQUE NOT NULL,"
                + "password VARCHAR(255) NOT NULL,"
                + "role VARCHAR(20) DEFAULT 'student')";
        String sqlNotes = "CREATE TABLE IF NOT EXISTS notes ("
                + "id INT AUTO_INCREMENT PRIMARY KEY,"
                + "user_id INT,"
                + "title VARCHAR(150),"
                + "content TEXT,"
                + "voice_path VARCHAR(255),"
                + "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                + "FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL)";
        try (Connection c = getConnection(); Statement s = c.createStatement()) {
            s.execute(sqlUsers);
            s.execute(sqlNotes);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
