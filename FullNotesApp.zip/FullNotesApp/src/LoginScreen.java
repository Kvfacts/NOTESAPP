import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class LoginScreen extends JFrame {
    private JTextField tfUser;
    private JPasswordField pfPass;

    public LoginScreen() {
        setTitle("Login - Notes App");
        setSize(360,220);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
    }

    private void initUI() {
        JPanel p = new JPanel();
        p.setLayout(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(8,8,8,8);
        g.gridx=0; g.gridy=0; p.add(new JLabel("Username:"), g);
        tfUser = new JTextField(16); g.gridx=1; p.add(tfUser, g);
        g.gridx=0; g.gridy=1; p.add(new JLabel("Password:"), g);
        pfPass = new JPasswordField(16); g.gridx=1; p.add(pfPass, g);
        JButton btnLogin = new JButton("Login");
        g.gridx=0; g.gridy=2; g.gridwidth=2; p.add(btnLogin, g);
        add(p);
        btnLogin.addActionListener(e -> tryLogin());
    }

    private void tryLogin() {
        String user = tfUser.getText().trim();
        String pass = new String(pfPass.getPassword());
        if (user.isEmpty() || pass.isEmpty()) { JOptionPane.showMessageDialog(this,"Enter credentials"); return; }
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT id,role FROM users WHERE username=? AND password=?")) {
            ps.setString(1, user);
            ps.setString(2, pass);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int id = rs.getInt("id");
                SwingUtilities.invokeLater(() -> {
                    new Dashboard(id, user).setVisible(true);
                });
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,"DB error: " + ex.getMessage());
        }
    }
}
