import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class Dashboard extends JFrame {
    private int userId;
    private String username;
    private JLabel lblTotal, lblVoice, lblLast;

    public Dashboard(int userId, String username) {
        this.userId = userId; this.username = username;
        setTitle("Dashboard - " + username);
        setSize(900,600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
        loadStats();
    }

    private void initUI() {
        setLayout(new BorderLayout());
        JPanel head = new JPanel(new BorderLayout());
        head.setBackground(new Color(0x3F51B5));
        JLabel l = new JLabel(" Notes Dashboard ", SwingConstants.LEFT);
        l.setForeground(Color.WHITE); l.setFont(new Font("Segoe UI", Font.BOLD, 24));
        head.add(l, BorderLayout.WEST);
        add(head, BorderLayout.NORTH);

        JPanel center = new JPanel(new GridLayout(1,3,12,12));
        center.setBorder(BorderFactory.createEmptyBorder(18,18,18,18));
        lblTotal = box("Total Notes", "0");
        lblVoice = box("Voice Notes", "0");
        lblLast  = box("Last Added", "-");
        center.add(lblTotal); center.add(lblVoice); center.add(lblLast);
        add(center, BorderLayout.CENTER);

        JPanel bottom = new JPanel();
        JButton btnNotes = new JButton("Open Notes");
        btnNotes.addActionListener(e -> new NotesPanel(userId, username).setVisible(true));
        bottom.add(btnNotes);
        add(bottom, BorderLayout.SOUTH);
    }

    private JLabel box(String title, String value) {
        JLabel box = new JLabel("<html><center><b>" + value + "</b><br>" + title + "</center></html>", SwingConstants.CENTER);
        box.setOpaque(true); box.setBackground(Color.WHITE); box.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        return box;
    }

    private void loadStats() {
        try (Connection c = DB.getConnection()) {
            try (Statement s = c.createStatement()) {
                ResultSet r = s.executeQuery("SELECT COUNT(*) FROM notes");
                if (r.next()) lblTotal.setText("<html><center><b>" + r.getInt(1) + "</b><br>Total Notes</center></html>");
                r = s.executeQuery("SELECT COUNT(*) FROM notes WHERE voice_path IS NOT NULL AND TRIM(voice_path)<>''");
                if (r.next()) lblVoice.setText("<html><center><b>" + r.getInt(1) + "</b><br>Voice Notes</center></html>");
                r = s.executeQuery("SELECT title FROM notes ORDER BY created_at DESC LIMIT 1");
                if (r.next()) lblLast.setText("<html><center><b>" + r.getString(1) + "</b><br>Last Added</center></html>");
            }
        } catch (SQLException ex) { ex.printStackTrace(); }
    }
}
