import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import java.io.File;
import java.io.IOException;

public class PdfExporter {
    public static void exportNote(File out, String title, String content, String voicePath) throws IOException {
        PDDocument doc = new PDDocument();
        PDPage page = new PDPage();
        doc.addPage(page);
        PDPageContentStream cs = new PDPageContentStream(doc, page);
        cs.beginText();
        cs.setFont(PDType1Font.HELVETICA_BOLD, 18);
        cs.newLineAtOffset(50, 700);
        cs.showText(title != null ? title : "Note");
        cs.endText();

        cs.beginText();
        cs.setFont(PDType1Font.HELVETICA, 12);
        cs.newLineAtOffset(50, 660);
        String[] lines = splitToLines(content != null ? content : "", 90);
        for (String line : lines) {
            cs.showText(line);
            cs.newLineAtOffset(0, -14);
        }
        cs.endText();

        cs.beginText();
        cs.setFont(PDType1Font.HELVETICA_OBLIQUE, 10);
        cs.newLineAtOffset(50, 120);
        cs.showText("Voice attached: " + (voicePath == null ? "No" : voicePath));
        cs.endText();

        cs.close();
        doc.save(out);
        doc.close();
    }

    private static String[] splitToLines(String text, int max) {
        if (text.length() <= max) return new String[]{text};
        int parts = (text.length() + max - 1) / max;
        String[] arr = new String[parts];
        for (int i = 0; i < parts; i++) {
            int start = i * max;
            int end = Math.min(text.length(), start + max);
            arr[i] = text.substring(start, end);
        }
        return arr;
    }
}
