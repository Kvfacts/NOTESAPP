import javax.sound.sampled.LineUnavailableException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class NotesPanel extends JFrame {
    private int userId; private String username;
    private DefaultTableModel model; private JTable table;
    private JTextField tfTitle, tfContent; private JLabel status;
    private VoiceRecorder recorder; private File currentRecording;

    public NotesPanel(int userId, String username) {
        this.userId = userId; this.username = username;
        setTitle("Notes - " + username);
        setSize(1000,680);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        recorder = new VoiceRecorder();
        initUI();
        ensureFolders();
        loadNotes();
    }

    private void ensureFolders() {
        new File("voice").mkdirs();
        new File("exports").mkdirs();
    }

    private void initUI() {
        setLayout(new BorderLayout());
        JPanel head = new JPanel(new BorderLayout());
        head.setBackground(new Color(0x512DA8));
        JLabel t = new JLabel("Notes Pro", SwingConstants.LEFT);
        t.setForeground(Color.WHITE); t.setFont(new Font("Segoe UI", Font.BOLD, 22));
        t.setBorder(new EmptyBorder(10,12,10,12));
        head.add(t, BorderLayout.WEST);
        status = new JLabel("Ready"); status.setForeground(Color.WHITE); status.setBorder(new EmptyBorder(10,12,10,12));
        head.add(status, BorderLayout.EAST);
        add(head, BorderLayout.NORTH);

        JPanel left = new JPanel(); left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setBorder(new EmptyBorder(12,12,12,12));
        tfTitle = new JTextField(); tfContent = new JTextField();
        left.add(new JLabel("Title:")); left.add(tfTitle); left.add(Box.createRigidArea(new Dimension(0,8)));
        left.add(new JLabel("Content:")); left.add(tfContent); left.add(Box.createRigidArea(new Dimension(0,12)));
        JButton btnAdd = new JButton("Add Note"); JButton btnDelete = new JButton("Delete Selected");
        JButton btnRecord = new JButton("Record Voice"); JButton btnStop = new JButton("Stop Recording");
        JButton btnPlay = new JButton("Play Voice"); JButton btnExport = new JButton("Export PDF");
        left.add(btnAdd); left.add(Box.createRigidArea(new Dimension(0,6)));
        left.add(btnDelete); left.add(Box.createRigidArea(new Dimension(0,6)));
        left.add(btnRecord); left.add(Box.createRigidArea(new Dimension(0,6)));
        left.add(btnStop); left.add(Box.createRigidArea(new Dimension(0,6)));
        left.add(btnPlay); left.add(Box.createRigidArea(new Dimension(0,6)));
        left.add(btnExport);
        add(left, BorderLayout.WEST);

        model = new DefaultTableModel(new Object[]{"ID","Title","Content","Voice","Created"},0) {
            public boolean isCellEditable(int r,int c){ return false; }
        };
        table = new JTable(model); table.setRowHeight(28);
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnAdd.addActionListener(e -> addNote());
        btnDelete.addActionListener(e -> deleteSelected());
        btnRecord.addActionListener(e -> {
            try { startRecord(); status.setText("Recording..."); } catch (LineUnavailableException ex) { ex.printStackTrace(); JOptionPane.showMessageDialog(this,"Mic error"); }
        });
        btnStop.addActionListener(e -> { stopRecord(); status.setText("Saved: " + (currentRecording != null ? currentRecording.getName() : "")); });
        btnPlay.addActionListener(e -> playSelectedVoice());
        btnExport.addActionListener(e -> exportSelected());
    }

    private void addNote() {
        String title = tfTitle.getText().trim(), content = tfContent.getText().trim();
        if (title.isEmpty() && content.isEmpty()) { JOptionPane.showMessageDialog(this,"Enter data"); return; }
        String sql = "INSERT INTO notes (user_id, title, content) VALUES (?, ?, ?)";
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setObject(1, userId);
            ps.setString(2, title);
            ps.setString(3, content);
            ps.executeUpdate();
            loadNotes(); tfTitle.setText(""); tfContent.setText(""); status.setText("Note added");
        } catch (SQLException ex) { ex.printStackTrace(); JOptionPane.showMessageDialog(this,"DB error"); }
    }

    private void loadNotes() {
        model.setRowCount(0);
        String sql = "SELECT id,title,content,voice_path,created_at FROM notes WHERE user_id=? OR user_id IS NULL ORDER BY id DESC";
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setObject(1, userId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("content"),
                        rs.getString("voice_path"),
                        rs.getTimestamp("created_at")
                });
            }
            status.setText("Loaded " + model.getRowCount());
        } catch (SQLException ex) { ex.printStackTrace(); }
    }

    private void deleteSelected() {
        int r = table.getSelectedRow(); if (r == -1) { JOptionPane.showMessageDialog(this,"Select a row"); return; }
        int id = (int) model.getValueAt(r,0);
        int ok = JOptionPane.showConfirmDialog(this,"Delete ID " + id + "?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (ok != JOptionPane.YES_OPTION) return;
        String sql = "DELETE FROM notes WHERE id=?";
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id); ps.executeUpdate(); loadNotes(); status.setText("Deleted");
        } catch (SQLException ex) { ex.printStackTrace(); }
    }

    private void startRecord() throws LineUnavailableException {
        String fname = "voice_" + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".wav";
        File f = new File("voice", fname); currentRecording = f;
        recorder.startRecording(f);
    }

    private void stopRecord() {
        recorder.stopRecording();
        int r = table.getSelectedRow();
        if (r != -1) {
            int id = (int) model.getValueAt(r,0);
            try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement("UPDATE notes SET voice_path=? WHERE id=?")) {
                ps.setString(1, currentRecording.getAbsolutePath()); ps.setInt(2, id); ps.executeUpdate(); loadNotes(); status.setText("Attached to ID " + id);
            } catch (SQLException ex) { ex.printStackTrace(); }
        } else {
            try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement("INSERT INTO notes (user_id,title,content,voice_path) VALUES (?,?,?,?)")) {
                ps.setObject(1, userId); ps.setString(2, "Voice Note"); ps.setString(3, ""); ps.setString(4, currentRecording.getAbsolutePath()); ps.executeUpdate(); loadNotes(); status.setText("Voice note created");
            } catch (SQLException ex) { ex.printStackTrace(); }
        }
    }

    private void playSelectedVoice() {
        int r = table.getSelectedRow(); if (r == -1) { JOptionPane.showMessageDialog(this,"Select a row"); return; }
        String vp = (String) model.getValueAt(r,3); if (vp == null || vp.isEmpty()) { JOptionPane.showMessageDialog(this,"No voice attached"); return; }
        try {
            javax.sound.sampled.AudioInputStream ais = javax.sound.sampled.AudioSystem.getAudioInputStream(new File(vp));
            javax.sound.sampled.Clip clip = javax.sound.sampled.AudioSystem.getClip();
            clip.open(ais); clip.start();
        } catch (Exception ex) { ex.printStackTrace(); JOptionPane.showMessageDialog(this,"Play error"); }
    }

    private void exportSelected() {
        int r = table.getSelectedRow(); if (r == -1) { JOptionPane.showMessageDialog(this,"Select a row"); return; }
        int id = (int) model.getValueAt(r,0); String title = (String) model.getValueAt(r,1); String content = (String) model.getValueAt(r,2); String voice = (String) model.getValueAt(r,3);
        File out = new File("exports", "note_" + id + "_" + System.currentTimeMillis() + ".pdf");
        try { PdfExporter.exportNote(out, title, content, voice); Desktop.getDesktop().open(out); } catch (Exception ex) { ex.printStackTrace(); JOptionPane.showMessageDialog(this,"Export failed"); }
    }
}
