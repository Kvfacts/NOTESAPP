import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;

public class VoiceRecorder {
    private TargetDataLine line;
    private AudioFileFormat.Type fileType = AudioFileFormat.Type.WAVE;

    public void startRecording(File outputFile) throws LineUnavailableException {
        AudioFormat format = getFormat();
        DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
        if (!AudioSystem.isLineSupported(info)) throw new LineUnavailableException("Microphone line not supported");
        line = (TargetDataLine) AudioSystem.getLine(info);
        line.open(format);
        line.start();

        Thread thread = new Thread(() -> {
            try {
                AudioSystem.write(new AudioInputStream(line), fileType, outputFile);
            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
        });
        thread.start();
    }

    public void stopRecording() {
        if (line != null) {
            line.stop();
            line.close();
            line = null;
        }
    }

    private AudioFormat getFormat() {
        float sampleRate = 16000;
        int sampleSizeInBits = 16;
        int channels = 1;
        boolean signed = true;
        boolean bigEndian = false;
        return new AudioFormat(sampleRate, sampleSizeInBits, channels, signed, bigEndian);
    }
}
